#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
: "${ANDROID_HOME:?Set ANDROID_HOME to your Android SDK directory}"
: "${DJ_POWER_KEYSTORE:?Set DJ_POWER_KEYSTORE to your own signing keystore path}"
: "${DJ_POWER_KEY_ALIAS:?Set DJ_POWER_KEY_ALIAS to your signing alias}"
: "${DJ_POWER_STORE_PASS_FILE:?Set DJ_POWER_STORE_PASS_FILE to a local password-file path}"
BT="$ANDROID_HOME/build-tools/${BUILD_TOOLS_VERSION:-35.0.0}"
JAR="$ANDROID_HOME/platforms/android-35/android.jar"
OUTPUT="${DJ_POWER_APK_OUTPUT:-out/DJ-POWER-v1.5.apk}"
rm -rf out/classes out/dex out/compiled
mkdir -p out/classes out/dex out/compiled "$(dirname "$OUTPUT")"
"$BT/aapt2" compile --dir res -o out/compiled.zip
"$BT/aapt2" link -o out/unsigned.apk --manifest AndroidManifest.xml -I "$JAR" -A assets out/compiled.zip --auto-add-overlay
javac -encoding UTF-8 -source 8 -target 8 -cp "$JAR" -d out/classes $(find src -name '*.java')
"$BT/d8" --lib "$JAR" --min-api 26 --output out/dex $(find out/classes -name '*.class')
(cd out/dex && zip -q ../unsigned.apk classes.dex)
"$BT/zipalign" -f 4 out/unsigned.apk out/aligned.apk
"$BT/apksigner" sign --ks "$DJ_POWER_KEYSTORE" --ks-key-alias "$DJ_POWER_KEY_ALIAS" --ks-pass "file:$DJ_POWER_STORE_PASS_FILE" --out "$OUTPUT" out/aligned.apk
"$BT/apksigner" verify --verbose "$OUTPUT"
"$BT/aapt" dump badging "$OUTPUT" | head -15
