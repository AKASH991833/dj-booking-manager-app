package com.akash.djpower;
import android.app.job.*;
public class BackupJob extends JobService {
 @Override public boolean onStartJob(JobParameters p){new Thread(()->{boolean ok=BackupStore.refresh(this);jobFinished(p,!ok);}).start();return true;}
 @Override public boolean onStopJob(JobParameters p){return true;}
}
