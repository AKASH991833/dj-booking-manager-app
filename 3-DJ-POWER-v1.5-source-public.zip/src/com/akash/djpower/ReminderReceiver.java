package com.akash.djpower;
import android.content.*;
public class ReminderReceiver extends BroadcastReceiver {public void onReceive(Context c,Intent i){if("com.akash.djpower.FUNCTION".equals(i.getAction()))Reminders.notify(c,i);else Reminders.schedule(c);}}
