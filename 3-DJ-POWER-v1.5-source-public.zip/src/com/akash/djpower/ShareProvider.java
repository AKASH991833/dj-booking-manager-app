package com.akash.djpower;
import android.content.*;import android.database.*;import android.net.Uri;import android.os.ParcelFileDescriptor;import android.provider.OpenableColumns;import java.io.*;
public class ShareProvider extends ContentProvider {
 @Override public boolean onCreate(){return true;}
 File file(Uri u)throws FileNotFoundException{try{File dir=new File(getContext().getCacheDir(),"shared").getCanonicalFile();File f=new File(dir,u.getLastPathSegment()).getCanonicalFile();if(!f.getParentFile().equals(dir)||!f.exists())throw new FileNotFoundException();return f;}catch(IOException e){throw new FileNotFoundException();}}
 @Override public ParcelFileDescriptor openFile(Uri u,String mode)throws FileNotFoundException{return ParcelFileDescriptor.open(file(u),ParcelFileDescriptor.MODE_READ_ONLY);}
 @Override public Cursor query(Uri u,String[] p,String s,String[] a,String o){try{File f=file(u);MatrixCursor c=new MatrixCursor(new String[]{OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE});c.addRow(new Object[]{f.getName(),f.length()});return c;}catch(Exception e){return null;}}
 @Override public String getType(Uri u){String n=String.valueOf(u.getLastPathSegment()).toLowerCase();return n.endsWith(".pdf")?"application/pdf":n.endsWith(".png")?"image/png":n.endsWith(".xlsx")?"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet":"application/octet-stream";}
 @Override public Uri insert(Uri u,ContentValues v){throw new UnsupportedOperationException();}
 @Override public int delete(Uri u,String s,String[] a){throw new UnsupportedOperationException();}
 @Override public int update(Uri u,ContentValues v,String s,String[] a){throw new UnsupportedOperationException();}
}
